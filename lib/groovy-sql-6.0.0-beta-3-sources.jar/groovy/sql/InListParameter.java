/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.sql;

import java.util.Collection;

/**
 * Marker that expands a collection into a comma-separated list of
 * positional placeholders when bound to a SQL {@code IN} clause.
 * <p>
 * Create instances via {@link Sql#inList(Collection)}.
 *
 * @since 6.0.0
 */
public interface InListParameter {
    /**
     * Returns the values that should be expanded into positional placeholders.
     *
     * @return the values for the expanded {@code IN} list
     */
    Collection<?> getValues();
}
