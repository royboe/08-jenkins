/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.groovy.ginq.provider.collection.runtime;

import groovy.lang.GroovyRuntimeException;

import java.io.Serial;

/**
 * Thrown when too many values returned by sub-query in the {@code select} clause
 *
 * @since 4.0.0
 */
public class TooManyValuesException extends GroovyRuntimeException {
    @Serial private static final long serialVersionUID = -2479599910868287387L;

    /**
     * Creates an exception for a sub-query that returned too many values.
     *
     * @param msg the error message
     */
    public TooManyValuesException(String msg) {
        super(msg);
    }
}
